enum FieldTypeEnums {
  text,
  checkbox,
  checkboxGroup,
  choiceChip,
  dateRangePicker,
  dateTimePicker,
  dropdown,
  filterChip,
  radioGroup,
  rangeSlider,
  slider,
  switchField,
}
