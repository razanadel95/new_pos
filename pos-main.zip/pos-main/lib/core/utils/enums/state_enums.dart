enum StateEnum {
  initial,
  loading,
  success,
  error,
  added,
  deleted,
  updated,
  deleting,
  adding,
  updating,
  deleteError,
  addError,
  updateError
}
