enum SharedPrefEnums {
  onboarding,
  RefrashToken,
  AccessToken,
  user,
}
