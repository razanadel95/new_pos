enum SplashType {
  custom,
  gif,
  lottie,
  fadeIn,
  scale,
}